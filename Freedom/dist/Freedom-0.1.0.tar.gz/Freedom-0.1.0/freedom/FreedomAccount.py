

class FreedomAccount:
    """
    A class representing a Freedom Mobile account.
    """

    def __init__(self) -> None:
        """
        Initialize the FreedomAccount object.
        """

        # Basic information
        self.first_name = None
        self.last_name = None
        self.account_number = None
        self.phone_number = None

        # Bill information
        self.balance = None
        self.due_date = None
        self.start_date = None
        self.end_date = None

    def get_first_name(self) -> str:
        """
        Get the first name of the account.
        """

        return self.first_name

    def get_last_name(self) -> str:
        """
        Get the last name of the account.
        """

        return self.last_name

    def get_account_number(self) -> str:
        """
        Get the account number of the account.
        """

        return self.account_number

    def get_phone_number(self) -> str:
        """
        Get the phone number of the account.
        """

        return self.phone_number

    def get_balance(self) -> float:
        """
        Get the balance of the account.
        """

        return self.balance

    def get_due_date(self) -> str:
        """
        Get the due date of the account.
        """

        return self.due_date

    def get_start_date(self) -> str:
        """
        Get the start date of the account.
        """

        return self.start_date

    def get_end_date(self) -> str:
        """
        Get the end date of the account.
        """

        return self.end_date

    def set_first_name(self, first_name: str) -> None:
        """
        Set the first name of the account.
        :param first_name:
        :return:
        """
        self.first_name = first_name

    def set_last_name(self, last_name: str) -> None:
        """
        Set the last name of the account.
        :param last_name:
        :return:
        """
        self.last_name = last_name

    def set_account_number(self, account_number: str) -> None:
        """
        Set the account number of the account.
        :param account_number:
        :return:
        """
        self.account_number = account_number

    def set_phone_number(self, phone_number: str) -> None:
        """
        Set the phone number of the account.
        :param phone_number:
        :return:
        """
        self.phone_number = phone_number

    def set_balance(self, balance: float) -> None:
        """
        Set the balance of the account.
        :param balance:
        :return:
        """
        self.balance = balance

    def set_due_date(self, due_date: str) -> None:
        """
        Set the due date of the account.
        :param due_date:
        :return:
        """
        self.due_date = due_date

    def set_start_date(self, start_date: str) -> None:
        """
        Set the start date of the account.
        :param start_date:
        :return:
        """
        self.start_date = start_date

    def set_end_date(self, end_date: str) -> None:
        """
        Set the end date of the account.
        :param end_date:
        :return:
        """
        self.end_date = end_date


def account_from_service_item(service_item: dict) -> FreedomAccount:
    """
    Create a FreedomAccount object from a service item.
    :param service_item:
    :return:
    """

    account = FreedomAccount()
    account.set_first_name(service_item["FirstName"])
    account.set_last_name(service_item["LastName"])

    billing_info = service_item["BillingInfo"]

    account.set_account_number(billing_info["AccountNumber"])
    account.set_phone_number(billing_info["Msisdn"])
    account.set_balance(billing_info["Balance"])
    account.set_due_date(billing_info["PaymentDueDate"])
    account.set_start_date(billing_info["BillingStartDate"])
    account.set_end_date(billing_info["BillingEndDate"])

    return account
